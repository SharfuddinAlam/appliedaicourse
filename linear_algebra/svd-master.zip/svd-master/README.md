# svd
Studies in Singular Value Decomposition.

1. [Singular Value Decomposition for Data Visualization](https://nbviewer.jupyter.org/github/buruzaemon/svd/blob/master/01_SVD_visualizing_data.ipynb) (on nbviewer.jupyter.org)

